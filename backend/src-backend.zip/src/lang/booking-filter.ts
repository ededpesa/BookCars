import LocalizedStrings from "react-localization";
import * as langHelper from "../common/langHelper";

const strings = new LocalizedStrings({
  fr: {
    PICK_UP_LOCATION: "Lieu de prise en charge",
    DROP_OFF_LOCATION: "Lieu de restitution",
  },
  en: {
    PICK_UP_LOCATION: "Pickup location",
    DROP_OFF_LOCATION: "Drop-off location",
  },
  es: {
    PICK_UP_LOCATION: "Ubicación de recogida",
    DROP_OFF_LOCATION: "Ubicación de entrega",
  },
});

langHelper.setLanguage(strings);
export { strings };
